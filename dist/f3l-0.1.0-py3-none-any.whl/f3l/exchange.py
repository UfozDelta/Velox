import requests


class AbstractExchange:
    """An Abstract Exchange Class"""

    api: str
    secret:str
    url: str
    def __init__(self, api, secret, url):
        self.api = api
        self.url = url
        self.secret = secret

    def orders():
        raise NotImplementedError
    
    def limit():
        raise NotImplementedError
    
    def market():
        raise NotImplementedError

class KuCoin(AbstractExchange):
    """KuCoin Futures Exchange Implementation"""

    url:str
    api:str
    secret:str

    def __init__(self, api, secret, url):
        super().__init__(api, secret, url)

    def orders():
        pass

    def limit():
        pass

    def market():
        pass

    def price(symbol):
        r = requests.get("https://api-futures.kucoin.com/api/v1/mark-price/{symbol}/current").json()


class ByBit(AbstractExchange):
    """Bybit Futures Exchange Implementation"""
    pass

class Binance(AbstractExchange):
    """Binance Futures Exchange Implementation"""
    pass

class Aggregated:
    """Aggregated Info"""
    pass