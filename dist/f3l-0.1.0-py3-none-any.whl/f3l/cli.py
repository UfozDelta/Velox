import click
import requests
from exchange import KuCoin, Binance, ByBit
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Dictionary to store exchange instances
EXCHANGE_INSTANCES = {
    "kucoin": KuCoin(os.getenv("KuCoinAPI"), os.getenv("KuCoinSecret"), "https://api-futures.kucoin.com"),
    "binance": Binance(os.getenv("BinanceAPI"), os.getenv("BinanceSecret"), "https://api.binance.com"),
    "bybit": ByBit(os.getenv("ByBitAPI"), os.getenv("ByBitSecret"), "https://api.bybit.com")
}


@click.group()
@click.option("--exchange", type=click.Choice(["kucoin", "binance", "bybit"], case_sensitive=False), default="kucoin", help="Choose exchange")
@click.pass_context
def cli(ctx, exchange):
    """CLI tool to interact with crypto exchanges."""
    ctx.obj = EXCHANGE_INSTANCES[exchange]


@cli.command()
@click.argument("symbol", default="BTCUSDT")
@click.pass_obj
def price(exchange, symbol):
    """Fetch market price from the selected exchange."""
    result = exchange.price(symbol)
    click.echo(f"{symbol.upper()} price: {result}")


@cli.command()
@click.pass_obj
def orders(exchange):
    """Fetch open limit orders for the selected exchange."""
    result = exchange.orders()
    click.echo(result)


@cli.command()
@click.argument("price")
@click.argument("symbol", default="BTCUSDT")
@click.argument("type_order", default="LIMIT")
@click.pass_obj
def open(exchange, price, symbol, type_order):
    """Create a limit order on the selected exchange."""
    result = exchange.open_order(price, symbol, type_order)
    click.echo(result)


if __name__ == "__main__":
    cli()